from colorama import Fore, Style

def main():
    print(Fore.RED + "Hello!")
    print(Style.RESET_ALL)


if __name__ == '__main__':
    main()
